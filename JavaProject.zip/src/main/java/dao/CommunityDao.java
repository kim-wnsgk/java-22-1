package dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import dto.Community;

public class CommunityDao {

	private static long nextId = 0;
	
	private Map<String, Community> map = new HashMap<>();
	
	//삽입. 일단 db위주 개발 먼저
}
