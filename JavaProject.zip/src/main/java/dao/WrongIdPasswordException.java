//�쉶�썝�뜲�씠�꽣
package dao;
public class WrongIdPasswordException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
